"use client"

import { useState, useEffect } from "react"
import { CodeBlock } from "@/lib/types"
import { shuffleArray } from "@/lib/sorting-algorithms"
import { CheckCircle, XCircle, GripVertical, AlertTriangle } from "lucide-react"

interface CodeArrangementGameProps {
  blocks: CodeBlock[]
  onCorrect: () => void
  onIncorrect: (errorMessage: string) => void
}

export function CodeArrangementGame({ blocks, onCorrect, onIncorrect }: CodeArrangementGameProps) {
  const [arrangedBlocks, setArrangedBlocks] = useState<CodeBlock[]>([])
  const [availableBlocks, setAvailableBlocks] = useState<CodeBlock[]>([])
  const [isChecking, setIsChecking] = useState(false)
  const [result, setResult] = useState<"correct" | "incorrect" | null>(null)
  const [errorMessage, setErrorMessage] = useState("")
  const [draggedBlock, setDraggedBlock] = useState<CodeBlock | null>(null)

  useEffect(() => {
    setAvailableBlocks(shuffleArray(blocks))
    setArrangedBlocks([])
    setResult(null)
    setErrorMessage("")
    setIsChecking(false)
  }, [blocks])

  const handleAddBlock = (block: CodeBlock) => {
    if (isChecking) return
    setArrangedBlocks(prev => [...prev, block])
    setAvailableBlocks(prev => prev.filter(b => b.id !== block.id))
  }

  const handleRemoveBlock = (block: CodeBlock) => {
    if (isChecking) return
    setAvailableBlocks(prev => [...prev, block])
    setArrangedBlocks(prev => prev.filter(b => b.id !== block.id))
  }

  const handleDragStart = (block: CodeBlock) => {
    setDraggedBlock(block)
  }

  const handleDragOver = (e: React.DragEvent, targetBlock: CodeBlock) => {
    e.preventDefault()
    if (!draggedBlock || draggedBlock.id === targetBlock.id) return
    
    const dragIndex = arrangedBlocks.findIndex(b => b.id === draggedBlock.id)
    const targetIndex = arrangedBlocks.findIndex(b => b.id === targetBlock.id)
    
    if (dragIndex === -1 || targetIndex === -1) return
    
    const newBlocks = [...arrangedBlocks]
    newBlocks.splice(dragIndex, 1)
    newBlocks.splice(targetIndex, 0, draggedBlock)
    setArrangedBlocks(newBlocks)
  }

  const handleDragEnd = () => {
    setDraggedBlock(null)
  }

  const checkAnswer = () => {
    setIsChecking(true)
    
    setTimeout(() => {
      const isCorrect = arrangedBlocks.every(
        (block, index) => block.order === index + 1
      )

      if (isCorrect) {
        setResult("correct")
        setTimeout(onCorrect, 1500)
      } else {
        const firstWrongIndex = arrangedBlocks.findIndex(
          (block, index) => block.order !== index + 1
        )
        
        let error = ""
        if (firstWrongIndex !== -1) {
          const wrongBlock = arrangedBlocks[firstWrongIndex]
          if (wrongBlock.code.includes("for") && firstWrongIndex > 0 && !arrangedBlocks[firstWrongIndex - 1].code.includes("{")) {
            error = "Compile Error: Loop harus dimulai setelah deklarasi"
          } else if (wrongBlock.code.includes("}") && firstWrongIndex < 3) {
            error = "Compile Error: Closing brace muncul terlalu awal"
          } else if (wrongBlock.code.includes("temp") && !arrangedBlocks.slice(0, firstWrongIndex).some(b => b.code.includes("if"))) {
            error = "Logic Error: Variabel temp digunakan sebelum kondisi"
          } else {
            error = "Logic Error: Urutan kode tidak sesuai algoritma"
          }
        } else {
          error = "Error: Kode belum lengkap"
        }
        
        setErrorMessage(error)
        setResult("incorrect")
        setTimeout(() => onIncorrect(error), 2000)
      }
    }, 500)
  }

  const allPlaced = availableBlocks.length === 0

  return (
    <div className="space-y-4">
      {/* Code Editor Area */}
      <div className="bg-[#100F06] rounded-2xl p-4 min-h-[160px]">
        <div className="text-[10px] text-[#6B6B6B] mb-2 font-mono">// Susun kode di sini</div>
        {arrangedBlocks.length === 0 ? (
          <div className="text-[#6B6B6B] text-xs italic text-center py-6">
            Tap kode di bawah untuk menambahkan
          </div>
        ) : (
          <div className="space-y-1">
            {arrangedBlocks.map((block, index) => (
              <div
                key={block.id}
                draggable
                onDragStart={() => handleDragStart(block)}
                onDragOver={(e) => handleDragOver(e, block)}
                onDragEnd={handleDragEnd}
                onClick={() => handleRemoveBlock(block)}
                className={`flex items-center gap-2 p-2 rounded-xl cursor-pointer transition-all ${
                  result === "correct"
                    ? "bg-[#00917A]/30"
                    : result === "incorrect" && block.order !== index + 1
                    ? "bg-[#F47575]/30 animate-shake"
                    : "bg-[#2A2A2A] active:bg-[#3A3A3A]"
                } ${draggedBlock?.id === block.id ? "opacity-50" : ""}`}
              >
                <GripVertical className="w-4 h-4 text-[#6B6B6B]" />
                <code className="text-xs text-white font-mono">{block.code}</code>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Available Blocks */}
      <div className="space-y-2">
        <p className="text-xs font-medium text-[#6B6B6B]">
          Potongan kode:
        </p>
        <div className="space-y-2">
          {availableBlocks.map(block => (
            <button
              key={block.id}
              onClick={() => handleAddBlock(block)}
              disabled={isChecking}
              className="w-full p-3 bg-white rounded-2xl text-left font-mono text-xs border-2 border-[#E0DFD8] active:bg-[#F5F4ED] transition-colors disabled:opacity-50"
            >
              {block.code}
            </button>
          ))}
        </div>
      </div>

      {/* Result */}
      {result && (
        <div
          className={`p-4 rounded-2xl animate-slide-up ${
            result === "correct"
              ? "bg-[#00917A]/10 border-2 border-[#00917A]/30"
              : "bg-[#F47575]/10 border-2 border-[#F47575]/30"
          }`}
        >
          {result === "correct" ? (
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-[#00917A]" />
              <span className="font-semibold text-[#00917A]">Sempurna!</span>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <XCircle className="w-6 h-6 text-[#F47575]" />
                <span className="font-semibold text-[#F47575]">Belum benar!</span>
              </div>
              {errorMessage && (
                <div className="flex items-start gap-2 p-3 bg-[#100F06] rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-[#FFDA57] mt-0.5 flex-shrink-0" />
                  <p className="text-xs font-mono text-white">{errorMessage}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Check Button */}
      {!result && (
        <button
          className="w-full bg-[#100F06] text-white font-semibold py-4 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={!allPlaced || isChecking}
          onClick={checkAnswer}
        >
          {isChecking ? "Memeriksa..." : "Periksa Kode"}
        </button>
      )}
    </div>
  )
}
