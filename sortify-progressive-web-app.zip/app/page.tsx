"use client"

import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function WelcomePage() {
  return (
    <div className="min-h-screen bg-[#F5F4ED] px-6 py-8 flex flex-col">
      {/* Decorative elements */}
      <div className="absolute top-4 left-4 w-8 h-8 border-2 border-[#100F06] rounded-full opacity-20" />
      <div className="absolute top-12 right-8 w-4 h-4 bg-[#FFDA57] rounded-full" />
      <div className="absolute top-24 left-12 text-2xl opacity-30 font-display">~</div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center">
        {/* Mascot Area */}
        <div className="relative mb-8 animate-float">
          <div className="w-44 h-44 bg-[#FFDA57] rounded-[32px] flex items-center justify-center shadow-playful-lg relative">
            {/* Cute face */}
            <div className="relative">
              {/* Eyes */}
              <div className="flex gap-5 mb-3">
                <div className="w-7 h-7 bg-[#100F06] rounded-full relative">
                  <div className="absolute top-1 right-1 w-2 h-2 bg-white rounded-full" />
                </div>
                <div className="w-7 h-7 bg-[#100F06] rounded-full relative">
                  <div className="absolute top-1 right-1 w-2 h-2 bg-white rounded-full" />
                </div>
              </div>
              {/* Mouth */}
              <div className="w-5 h-2.5 border-b-[3px] border-[#100F06] rounded-b-full mx-auto" />
            </div>
            {/* Arms */}
            <div className="absolute -left-3 top-1/2 w-6 h-3 bg-[#FFDA57] rounded-full -rotate-45" />
            <div className="absolute -right-3 top-1/2 w-6 h-3 bg-[#FFDA57] rounded-full rotate-45" />
          </div>
          {/* Sparkles */}
          <div className="absolute -top-2 -right-2 text-lg">✨</div>
          <div className="absolute -bottom-1 -left-3 text-base">⭐</div>
        </div>

        {/* Dots indicator */}
        <div className="flex gap-2 mb-6">
          <div className="w-2 h-2 bg-[#100F06] rounded-full" />
          <div className="w-2 h-2 bg-[#100F06]/30 rounded-full" />
          <div className="w-2 h-2 bg-[#100F06]/30 rounded-full" />
        </div>

        {/* Title */}
        <h1 className="font-[var(--font-unbounded)] text-[28px] font-bold text-[#100F06] leading-tight text-center mb-3">
          Belajar Sorting
          <br />
          Jadi Seru!
        </h1>

        {/* Description */}
        <p className="text-[#6B6B6B] text-center text-sm leading-relaxed max-w-[260px]">
          Pahami algoritma sorting dengan visualisasi interaktif dan game puzzle yang menyenangkan
        </p>
      </div>

      {/* Bottom Actions */}
      <div className="space-y-3 pb-4">
        <Link 
          href="/register"
          className="flex items-center justify-center gap-2 w-full bg-[#00917A] text-white font-semibold text-base py-4 rounded-full shadow-playful active:translate-y-1 active:shadow-none transition-all"
        >
          <span>Get Started</span>
          <ArrowRight className="w-5 h-5" />
        </Link>

        <Link 
          href="/login"
          className="flex items-center justify-center w-full bg-white text-[#100F06] font-medium text-base py-4 rounded-full border-2 border-[#E0DFD8] active:bg-[#F5F4ED] transition-all"
        >
          Sudah punya akun? Masuk
        </Link>
      </div>
    </div>
  )
}
